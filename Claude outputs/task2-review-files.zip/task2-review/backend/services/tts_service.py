"""Application TTS service: validate -> persisted job -> synthesize -> validate/store audio -> final status.

Short TTS jobs share the same durable job model as long-form/clone jobs
(backend.persistence.Repository, kind='short'): QUEUED -> RUNNING ->
COMPLETED/FAILED, recovered to FAILED/INTERRUPTED on restart (no resume).
A single background worker thread serializes actual synthesis through the
shared application inference lock, mirroring LongFormTTSService. The legacy
synchronous `synthesize()`/`POST /api/tts` contract is preserved by
submitting a job and polling it to a terminal state before returning.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import json
import logging
from pathlib import Path
import queue
import threading
import time
import uuid
import wave

from backend.config import Settings
from backend.errors import ApplicationError, ErrorCode
from backend.errors.handlers import MESSAGES
from backend.schemas.common import ErrorBody
from backend.schemas.tts import TTSData, TTSRequest, TTSResponse, TTSStatus
from backend.services.provider_service import ProviderService
from core.audio_utils import export_mp3
from core.languages import VERIFIED, language_status
from backend.persistence import Repository

logger = logging.getLogger("backend.tts")
MAX_TEXT_LENGTH = 2000
JOB_KIND = "short"
TERMINAL = {"COMPLETED", "FAILED"}
POLL_INTERVAL_SECONDS = 0.01
# Safety net only: short-TTS generation is expected to finish in well under a
# second against a real provider. This bounds the legacy synchronous wrapper
# so a stuck worker cannot hang an HTTP request forever.
LEGACY_WAIT_TIMEOUT_SECONDS = 60.0


@dataclass
class _Job:
    snapshot: TTSStatus
    # In-memory-only synthesis parameters for THIS process's worker to consume.
    # Never persisted directly (execution_snapshot already carries the raw
    # request for audit purposes); cleared once the job reaches a terminal
    # state so raw customer text is not retained longer than necessary.
    params: dict | None = None
    # Safe, small, persisted metadata only (no raw text) - written to the
    # database's diagnostics column on every transition.
    diagnostics: dict = field(default_factory=dict)


class TTSService:
    def __init__(self, settings: Settings, provider_service: ProviderService):
        self._settings = settings
        self._provider_service = provider_service
        self._output_dir = Path(settings.output_dir)
        self._output_dir.mkdir(parents=True, exist_ok=True)
        self._db = Repository(settings)
        # Explicit allowlist: do not serialize environment, credentials or auth configuration.
        self._db.put('settings', 'runtime', {
            'primary_tts_provider': settings.primary_tts_provider,
            'omnivoice_device': settings.omnivoice_device, 'app_version': settings.app_version})

        # Global recovery: any job (short/clone/long_form) left QUEUED/RUNNING
        # by a previous process is marked FAILED/INTERRUPTED here. TTSService
        # is constructed first in the app lifespan, so this is the earliest
        # point recovery can run before any service rehydrates job state from
        # history. Idempotent: a later Repository.recover() call (e.g. from
        # LongFormTTSService) simply finds nothing left to recover.
        self._db.recover()

        self._jobs: dict[str, _Job] = {}
        for snapshot, diagnostics in self._db.history(JOB_KIND):
            restored = TTSStatus(**snapshot)
            self._jobs[restored.job_id] = _Job(restored, diagnostics=diagnostics)

        self._lock = threading.RLock()
        self._queue: queue.Queue = queue.Queue()
        self._closed = False
        self._thread = threading.Thread(target=self._worker, name="short-tts", daemon=True)
        self._thread.start()

    @property
    def output_dir(self) -> Path:
        return self._output_dir

    def close(self):
        with self._lock:
            if self._closed:
                return
            self._closed = True
        self._queue.put(None)
        self._thread.join()  # Native inference finishes its current call safely.

    def validate_request(self, request: TTSRequest) -> tuple[str, str, str, float, str, str | None]:
        # Text validation: reject None, non-string, empty, whitespace-only
        text = request.text
        if text is None or not isinstance(text, str) or not text.strip():
            raise ApplicationError(ErrorCode.INVALID_TEXT)
        cleaned_text = text.strip()
        if len(cleaned_text) > MAX_TEXT_LENGTH:
            raise ApplicationError(ErrorCode.TEXT_TOO_LONG)

        # Language validation: only canonical verified languages
        language = request.language
        if not isinstance(language, str) or language_status(language) != VERIFIED:
            raise ApplicationError(ErrorCode.LANGUAGE_NOT_SUPPORTED)

        # Voice validation against provider without triggering model load
        provider = self._provider_service.get_primary_provider()
        voices = provider.list_voices(language)
        valid_voices = {v.id for v in voices}
        for voice in voices:
            self._db.put('voices', voice.id, {'id': voice.id, 'provider_id': provider.provider_name()})
        voice_id = request.voice_id
        if not voice_id:
            voice_id = "omnivoice_auto"
        if not isinstance(voice_id, str) or voice_id not in valid_voices:
            raise ApplicationError(ErrorCode.VOICE_NOT_FOUND)

        # Speed validation: must be a number, 0.5 <= speed <= 2.0 and speed == 1.0
        speed = request.speed
        if speed is None or isinstance(speed, bool) or not isinstance(speed, (int, float)):
            raise ApplicationError(ErrorCode.INVALID_SPEED)
        if not (0.5 <= speed <= 2.0) or float(speed) != 1.0:
            raise ApplicationError(ErrorCode.INVALID_SPEED)
        speed = float(speed)

        # Format validation: wav or mp3
        fmt = request.format
        if not isinstance(fmt, str) or fmt.lower() not in ("wav", "mp3"):
            raise ApplicationError(ErrorCode.INVALID_FORMAT)
        fmt = fmt.lower()

        # Idempotency key: optional, but if present must be a non-blank string.
        idempotency_key = request.idempotency_key
        if idempotency_key is not None:
            if not isinstance(idempotency_key, str) or not idempotency_key.strip():
                raise ApplicationError(ErrorCode.INVALID_REQUEST)
            idempotency_key = idempotency_key.strip()

        return cleaned_text, language, voice_id, speed, fmt, idempotency_key

    # ------------------------------------------------------------------
    # Async job API
    # ------------------------------------------------------------------

    def submit(self, request: TTSRequest) -> TTSStatus:
        text, language, voice_id, speed, fmt, idempotency_key = self.validate_request(request)

        execution = {
            'request': request.model_dump(), 'provider_id': self._settings.primary_tts_provider,
            'provider_version': None, 'model_revision': None, 'voice_revision': None, 'seed': None,
            'normalizer_version': 'strip-v1', 'chunker_version': None,
            'audio': {'sample_rate': 24000, 'channels': 1, 'format': fmt},
            'idempotency_key': idempotency_key,
        }

        with self._lock:
            if self._closed:
                raise ApplicationError(ErrorCode.SERVICE_UNAVAILABLE)

            if idempotency_key is not None:
                existing_id = self._db.find_job_by_idempotency_key(JOB_KIND, idempotency_key)
                if existing_id is not None:
                    return self._get(existing_id).snapshot

            job_id = str(uuid.uuid4())
            snapshot = TTSStatus(job_id=job_id, status="QUEUED")
            self._db.create_job(snapshot, execution, kind=JOB_KIND)
            job = _Job(snapshot, params={
                'text': text, 'language': language, 'voice_id': voice_id, 'speed': speed, 'format': fmt,
            })
            self._jobs[job_id] = job
            self._queue.put(job_id)
            return snapshot

    def _get(self, job_id) -> _Job:
        job = self._jobs.get(job_id)
        if job is None:
            db_job = self._db.get_job(job_id)
            if db_job and db_job.get("kind") == JOB_KIND:
                snapshot = TTSStatus(**json.loads(db_job["snapshot"]))
                diagnostics = json.loads(db_job.get("diagnostics") or "{}")
                job = _Job(snapshot, diagnostics=diagnostics)
                self._jobs[job_id] = job
                return job
            raise ApplicationError(ErrorCode.JOB_NOT_FOUND)
        return job

    def status(self, job_id: str) -> TTSStatus:
        with self._lock:
            return self._get(job_id).snapshot

    def history(self) -> list[TTSStatus]:
        """Persisted job history for this kind, oldest first."""
        return [TTSStatus(**snapshot) for snapshot, _ in self._db.history(JOB_KIND)]

    def _finish(self, job: _Job, status: str, *, audio_url=None, error=None, outputs=()):
        # Caller holds self._lock.
        snapshot = job.snapshot.model_copy(update={'status': status, 'audio_url': audio_url, 'error': error})
        self._db.save_job(snapshot, job.diagnostics, outputs)
        job.snapshot = snapshot
        job.params = None  # Terminal jobs release their source text reference.

    def _worker(self):
        while True:
            job_id = self._queue.get()
            if job_id is None:
                return
            # Shared with long-form and profile creation/test. Status stays
            # queued while another application inference owns the device.
            with self._provider_service.inference_lock:
                with self._lock:
                    job = self._jobs[job_id]
                    if job.snapshot.status != "QUEUED":
                        continue
                    job.snapshot = job.snapshot.model_copy(update={"status": "RUNNING"})
                    self._db.save_job(job.snapshot, job.diagnostics)
                self._run(job)

    def _run(self, job: _Job):
        params = job.params or {}
        text = params.get('text')
        language = params.get('language')
        voice_id = params.get('voice_id')
        speed = params.get('speed')
        fmt = params.get('format')

        generation_id = job.snapshot.job_id
        wav_path = self._output_dir / f"{generation_id}.wav"

        try:
            # Ensure primary provider is loaded (lazy model load)
            provider = self._provider_service.ensure_primary_provider_loaded()

            try:
                result = provider.synthesize(
                    text=text, language=language, voice=voice_id, output_path=wav_path, speed=speed,
                )
            except Exception as exc:
                logger.error("tts_synthesis_exception generation_id=%s error=%s", generation_id, exc)
                if wav_path.is_file():
                    try:
                        wav_path.unlink()
                    except Exception:
                        pass
                raise ApplicationError(ErrorCode.GENERATION_FAILED) from None

            if result.status != "PASS" or not wav_path.is_file():
                logger.error("tts_generation_failed generation_id=%s provider=%s language=%s error=%s",
                             generation_id, provider.provider_name(), language, result.error)
                if wav_path.is_file():
                    try:
                        wav_path.unlink()
                    except Exception:
                        pass
                raise ApplicationError(ErrorCode.GENERATION_FAILED)

            # Validate generated audio
            try:
                with wave.open(str(wav_path), "rb") as wf:
                    channels = wf.getnchannels()
                    sample_rate = wf.getframerate()
                    n_frames = wf.getnframes()
                    duration = n_frames / sample_rate if sample_rate > 0 else 0.0
                if channels != 1 or sample_rate != 24000 or duration <= 0.0:
                    raise ValueError("Invalid audio properties")
            except Exception as exc:
                logger.error("audio_validation_failed generation_id=%s error=%s", generation_id, exc)
                if wav_path.is_file():
                    try:
                        wav_path.unlink()
                    except Exception:
                        pass
                raise ApplicationError(ErrorCode.GENERATION_FAILED) from None

            # Optional MP3 export. On failure the WAV is deliberately retained
            # for diagnostics (existing, tested contract).
            mp3_path = None
            if fmt == "mp3":
                mp3_path = self._output_dir / f"{generation_id}.mp3"
                exported = export_mp3(wav_path, mp3_path)
                if exported is None or not mp3_path.is_file() or mp3_path.stat().st_size == 0:
                    logger.error("audio_export_failed generation_id=%s wav_retained=true", generation_id)
                    raise ApplicationError(ErrorCode.AUDIO_EXPORT_FAILED)

            logger.info(
                "tts_completed generation_id=%s provider=%s language=%s voice_id=%s format=%s "
                "duration=%.2f text_length=%d gen_time=%.2f",
                generation_id, result.provider_id, language, voice_id, fmt, duration, len(text), result.gen_time,
            )

            job.diagnostics = {
                **job.diagnostics,
                'result': {
                    'duration_seconds': duration, 'provider_id': result.provider_id,
                    'sample_rate': sample_rate, 'channels': 1, 'format': fmt,
                    'language': language, 'voice_id': voice_id,
                },
            }
            outputs = [wav_path] + ([mp3_path] if fmt == 'mp3' else [])
            with self._lock:
                self._finish(job, "COMPLETED", audio_url=f"/api/audio/{generation_id}.{fmt}", outputs=outputs)
        except Exception as exc:
            code = exc.code if isinstance(exc, ApplicationError) else ErrorCode.GENERATION_FAILED
            with self._lock:
                self._finish(job, "FAILED", error=ErrorBody(code=code.value, message=MESSAGES[code]))

    # ------------------------------------------------------------------
    # Legacy synchronous contract: POST /api/tts still returns 200 with a
    # completed TTSResponse. Implemented as submit() + poll so there is a
    # single job pipeline behind both the old and new API surfaces.
    # ------------------------------------------------------------------

    def synthesize(self, request: TTSRequest) -> TTSResponse:
        snapshot = self.submit(request)
        deadline = time.monotonic() + LEGACY_WAIT_TIMEOUT_SECONDS
        while snapshot.status not in TERMINAL:
            if time.monotonic() > deadline:
                raise ApplicationError(ErrorCode.SERVICE_UNAVAILABLE)
            time.sleep(POLL_INTERVAL_SECONDS)
            snapshot = self.status(snapshot.job_id)

        if snapshot.status == "FAILED":
            code = ErrorCode(snapshot.error.code) if snapshot.error else ErrorCode.GENERATION_FAILED
            raise ApplicationError(code)

        with self._lock:
            result = self._get(snapshot.job_id).diagnostics.get('result', {})
        return TTSResponse(
            ok=True,
            data=TTSData(
                generation_id=snapshot.job_id,
                status="completed",
                provider=result.get('provider_id', self._settings.primary_tts_provider),
                language=result.get('language'),
                voice_id=result.get('voice_id'),
                duration_seconds=round(result.get('duration_seconds', 0.0), 3),
                sample_rate=result.get('sample_rate', 24000),
                channels=result.get('channels', 1),
                format=result.get('format', 'wav'),
                audio_url=snapshot.audio_url,
            ),
        )
